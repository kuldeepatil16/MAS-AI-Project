**List of Rescued Persons:**

1. **John García**, 32
2. **Maria García**, 30
3. **Alex García**, 5
4. **Ms. Rodriguez**, 47
5. **Mr. Sanchez**, 65
6. **Mr. Lee**, 35
7. **Ms. Johnson**, 29
8. **Mr. Patel**, 42