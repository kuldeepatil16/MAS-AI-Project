Origin Coordinates (Longitude and Latitude):
39.45441 -0.36713
------------------------

Destination Coordinates (Longitude and Latitude):
-0.36332447406737145 39.46061969757309
------------------------

Estimated Travel Distance between Origin and Destination:
12345 meters