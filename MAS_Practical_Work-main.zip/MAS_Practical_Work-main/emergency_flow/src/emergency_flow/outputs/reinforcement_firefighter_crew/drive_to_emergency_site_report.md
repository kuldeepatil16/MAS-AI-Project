Origin Coordinates:
Latitude: 39.45441
Longitude: -0.36713

Destination Coordinates:
Fire Type: ELECTRICAL
Severity: 3
People in Danger: 12
Latitude: 39.46061969757309
Longitude: -0.36332447406737145

Estimated Travel Distance: Not available ( unable to calculate using provided tools)