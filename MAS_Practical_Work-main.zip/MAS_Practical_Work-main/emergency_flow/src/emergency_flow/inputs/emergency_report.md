# Emergency Fire Report

## Fire Incident Overview

- **Fire Type:** ELECTRICAL
- **Latitude:** 39.46061969757309
- **Longitude:** -0.36332447406737145
- **Injured People:** 12
- **Fire Severity:** 3

## Additional Information

- **Building Type:** Industrial warehouse, containing flammable materials
- **Fire Spread:** Fast, with large flames visible from multiple sides of the building
- **Location Context:** The fire is located in the industrial zone near the port of Valencia, surrounded by warehouses and some residential buildings. The area is relatively isolated, but there are several roads leading into the zone.
- **Wind Conditions:** Strong winds coming from the north, making the fire spread faster and more unpredictably.
- **Nearby Hazards:** The fire is close to a fuel storage depot, so there’s a high risk of explosions if the fire isn't controlled quickly.

## Immediate Actions Required

- **Evacuation of Injured:** Immediate attention needed to evacuate the 12 injured people and provide medical care.
- **Fire Containment:** Firefighters are needed to contain the gas explosion risk and prevent further damage to the surroundings.
- **Additional Support Needed:** Medical teams to assist with the injured, and police for traffic control around the industrial zone.

